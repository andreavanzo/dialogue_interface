#!/usr/bin/env python
import rospy
#from std_msgs.msg import String
from sensor_msgs.msg import Joy
import socket
import sys
import aiml

k = aiml.Kernel()

HOST = ''
PORT = 5001
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print 'Socket created'
try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
print 'Socket bind complete'
s.listen(10)
print 'Socket now listening on port ' + str(PORT)
k.learn("/home/turtlebot/catkin_ws/src/dialogue_interface/scripts/KB/dialogue_manager.aiml")
k.learn("/home/turtlebot/catkin_ws/src/dialogue_interface/scripts/KB/lexicon.aiml")
k.learn("/home/turtlebot/catkin_ws/src/dialogue_interface/scripts/KB/corridor.aiml")
k.learn("/home/turtlebot/catkin_ws/src/dialogue_interface/scripts/KB/coffee_machine.aiml")
k.learn("/home/turtlebot/catkin_ws/src/dialogue_interface/scripts/KB/inside_elevator.aiml")
k.learn("/home/turtlebot/catkin_ws/src/dialogue_interface/scripts/KB/outside_elevator.aiml")
k.learn("/home/turtlebot/catkin_ws/src/dialogue_interface/scripts/KB/printer.aiml")
k.respond('CORRIDOR')

def globalConn():
    global conn


def callback(data):
    #print test
    if data.buttons[1] == 1:
        #print test
        reply = k.respond('START')
        conn.send(reply + '\r\n')
        print reply

def listener():
    
    rospy.init_node('dialogue_interface_node', anonymous=True)

    rospy.Subscriber("joy", Joy, callback)
    #rospy.Subscriber("PSintControllerState", String, callback)
    currentFragment = ''
    while 1:
        conn, addr = s.accept()
        print 'Connected with ' + addr[0] + ':' + str(addr[1])
        while 1:
            data = conn.recv(512)
            if data and not data.isspace():
                if data == "JOY\n":
                        currentFragment = 'JOY'
                        print 'You selected the Joypad fragment'
                        continue
                elif data == "SPEECH\n":
        	        currentFragment = 'SPEECH'
        		print 'You selected the Speech fragment'
        		continue
        	elif data == "DIA\n":
        		currentFragment = 'DIA'
        		print 'You selected the Dialogue fragment'
        		continue
        	if currentFragment == "JOY":
	        	print data
        	elif currentFragment == "SPEECH":
	        	print data
        	elif currentFragment == "DIA":
        		if data.startswith('PROX:'):
        			splitted = data.split(":")
        			k.respond(splitted[1])
        			reply = k.respond('START')
        			conn.send(reply + '\r\n')
        			print 'proxemics ' + data
	        	else:
					print 'You said:' + data
					reply = k.respond(data)
					print 'Robot said:' + reply
					conn.send(reply + '\r\n')
        else:
            print 'Disconnected from ' + addr[0] + ':' + str(addr[1])
            break
    s.close()

if __name__ == '__main__':
    globalConn()
    listener()

